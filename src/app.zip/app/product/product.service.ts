import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Product } from './product';
{}

@Injectable({
  providedIn: 'root'
})
export class ProductService {
  // http: any;
  constructor(private http: HttpClient) { }

  getproducts(): Observable<Product[]>{
    return this.http.get<Product[]>(`http://103.98.6.125/products`);
  }

  addEditProduct(postData: any, selectedPdt:any){
    if(!selectedPdt){
      return this.http.post(`http://103.98.6.125/addproducts`, postData);
    }else{
      return this.http.put(`http://103.98.6.125/productupdate/${selectedPdt.id}`, postData);
    }
 
  }

  deleteProduct(productId: number): Observable<any> 
  {
    return this.http.delete(`http://103.98.6.125/productdelet/${productId}`);
  }
}
